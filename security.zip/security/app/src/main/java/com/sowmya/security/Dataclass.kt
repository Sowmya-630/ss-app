package com.sowmya.security

data class Contact(
    val name: String = "",
    val phone: String = ""
)